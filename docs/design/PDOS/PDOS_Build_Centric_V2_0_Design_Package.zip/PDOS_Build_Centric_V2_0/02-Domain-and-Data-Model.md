# PDOS V2.0｜领域模型、真值边界与一致性契约

- **版本：** V2.0 · 评审稿
- **日期：** 2026-09-28
- **适用：** 产品、后端、数据、AI 平台与测试团队。
- **前置：** [00 产品总纲](00-Master-Blueprint.md)
- **关联：** [01 页面交互](01-Information-Architecture-and-Page-Structure.md) · [03 Agent](03-Project-Agent-and-Capability-Architecture.md) · [04 流程验收](04-User-Flows-and-Acceptance-Scenarios.md)

> 本文是目标领域契约，不是现有数据库说明，也不是可直接执行的 DDL。对象可实现为聚合、子记录或带 schema 的值对象；一个逻辑对象不等于一个独立模块。

## 1. 总体模型与实现层级

```mermaid
flowchart TD
  SRC[SourceRef / ImportSnapshot] --> PRJ[Project]
  PB[ProductBaseline] --> PRJ
  PRJ --> DEF[有效需求、产品定义与规格]
  PRJ --> PROC[工艺定义与准备]
  DEF --> CFG[ConfigurationSnapshot]
  PROC --> CFG
  CFG --> BUILD[Build / Unit / Cohort]
  EXT[ExternalCommitment] --> READY[BuildReadiness 投影]
  CP[CommitmentPoint] --> READY
  BUILD --> READY
  BUILD --> OBS[交接、观测和验证]
  OBS --> FEED[问题 / 客户反馈]
  FEED --> CH[Change]
  CH --> CFG
  DEC[Decision] --> CP
  DEC --> REL[ProductRelease]
  REL --> PB
  REL --> HAND[ManufacturingRelease / ERP Handoff]
```

### 1.1 持久真值与投影

| 类别 | 持久真值 | 只读投影，禁止直接编辑 |
|---|---|---|
| 项目 | Project、PhaseChange、Decision | ProjectCommitState、Exploring 筛选 |
| 内容 | ContentItem / ContentRevision、ProjectOverlayEntry | EffectiveProjectContent、PRD/Spec 导出 |
| 配置 | ConfigurationSnapshot、ConfigurationEvent | 某台样机在某时刻的有效配置 |
| 开发节奏 | Build、BuildParticipation、BuildDisposition | 当前/下一轮视图、轮次统计 |
| 证据 | SourceRef、ObservationSet、MeasurementReview、CalculationResult | 需求验证覆盖与适用性结论 |
| 排期 | ExternalCommitmentRevision、日历、依赖、批准快照 | ScheduleForecast、承诺漂移 |
| 决策 | Decision、DecisionResponse、EvidenceSnapshot | 准备就绪、待补证清单 |
| 制造准备 | ProcessDefinition、验收/培训/试产事实 | ManufacturingReadiness |
| AI | AgentRun、DraftProposal、AIAnnotation | AI Brief；不得当正式批准依据 |

### 1.2 版本能力的最低实现

路线图仅见 00 第 12 节。V0 必须有：来源、不可变修订/快照、项目本地工作集、Build/配置/交接、观测确认、客户往返、变更、承诺、Decision 与受控 Agent。产品平台并行合并、完整工艺主数据和 ERP 生效不因本文定义而自动成为 V0 必做项。

### 1.3 领域实现深度对照（引用总纲，不另设路线图）

| 能力域 | V0 必须实现 | 后续扩展 |
|---|---|---|
| Product/Project | 产品目录可为空基线；一个项目一个锁定来源；项目本地修订不污染来源 | V1 产品正式发布；V2 完整平台/并行合并 |
| Baseline/配置 | 不可变来源、Build 授权证据与计划/实际/测试/提交配置 | V1 完整开发/产品/制造放行基线 |
| 工艺/资产 | 本轮 SOP、夹具/模具与试次的精确来源引用和验收证据 | V1 完整 ProcessDefinition/Operation/TrialAttempt 台账与试产指标 |
| BOM/成本 | 文件与关键物料配置；有依据的承诺费用项 | V1 结构化研发 BOM、放行交接；V2 平台 BOM Delta |
| 认证 | 要求、原文件、适用范围和未知项，不能自动认定有效 | V1 完整认证审查/实验室协调与制造放行使用 |
| AI/渠道 | 六组窄能力、手工/CRM 来源、钉钉深链、受控确认 | 专用工具接入按产品版本增加，不作为空租户前提 |

后续专用实体尚未实现时，V0 使用本轮所需的类型化来源引用/值对象，不用伪造一个完整资产、认证或工艺主数据模块。升级专用实体时保留来源与标识映射。

## 2. 通用标识、作用域与引用

### 2.1 标识约定

```text
UUID：内部身份。
display_key：如 BUILD-001，仅用于人类阅读，租户内唯一。
version：可变聚合的乐观并发版本。
revision_id：不可变内容修订身份，不与 version 混用。
digest：规范化内容哈希，用于识别内容与防止批准后替换。
```

`created_at / recorded_at` 表示系统登记时间；`occurred_at / effective_at` 表示有证据的业务发生/生效时间。导入旧文件不能把创建时间回填成历史批准时间。

### 2.2 Scope

```text
Scope
  scope_id, tenant_id
  scope_type: workspace | project | product
  scope_ref_id
```

每个内容项只有一个 `owner_scope_id`。Project、Product 的关联、使用、来源、发布关系必须另建绑定，不能用两个可空外键表达含糊归属。

工作项、交接等执行对象直接属于项目；长期外部资产可属于企业资产引用。各类所有权不强行归一，但每类必须只有一个明确主所有者。

### 2.3 ObjectRef 与 SourceRef

`ObjectRef` 是服务端类型化引用：`tenant_id + object_kind + object_id + revision_id/snapshot_id + digest`。历史关键引用必须精确到不可变版本；当前列表可使用可变聚合 ID，但不得用于批准证据。

`SourceRef` 记录来源，不自动证明来源内容是真的：

```text
SourceRef
  id, tenant_id
  source_system, source_object_id, source_revision
  source_kind: file | crm_message | external_record | manual_record | instrument_export
  captured_at, source_occurred_at?, imported_by
  blob_id?, canonical_content_digest
  locator: {sheet?, cell_range?, page?, region?, message_id?, json_path?}
  authority_class: raw_evidence | reported_claim | confirmed_record
  sensitivity_class, retention_policy_ref
```

所有外部字符串均视为数据，不是系统指令。访问 SourceRef 必须核验其访问策略，Project 引用不能自动跨客户授权。

SourceRef 的来源分类记录接入时的性质，不是模型对其真实性的评分。后续人工确认写独立记录，不覆盖原始来源的内容或时间。

### 2.4 FileBlob、ExternalObjectLink 与 Claim

- `FileBlob`：文件哈希、大小、媒体类型、存储定位、恶意文件检查状态；同租户可去重，不向别租户泄露文件存在性。
- `ExternalObjectLink`：本地对象与 CRM/ERP/专业系统对象的映射、版本与同步方向。
- `SourceClaim`：来源声称某事实，如“周五发货”；保存原文、抽取定位和确认状态，不是正式承诺修订。

外部材料需要的保存和访问权限必须配置；本模型不授权采集私人账号内容。

## 3. 内容模型：归属与修订不可混淆

### 3.1 ContentItem / ContentRevision

```text
ContentItem
  id, tenant_id, owner_scope_id
  kind: requirement | specification | product_definition | artifact |
        bom | process_definition | verification_plan
  stable_key, lineage_id
  origin_item_ref?

ContentRevision
  id, tenant_id, item_id
  revision_label, previous_revision_id?
  payload_schema_version, payload
  source_refs[], payload_digest
  created_by, created_at
```

每个 kind 的 `payload` 有强类型 schema。核心业务字段须校验并可索引，不允许以无校验 JSON 代替领域模型。保存内容修订采用完整值；不可变修订不接受 UPDATE。工作草案编辑可以有临时缓存，确认保存后形成修订。

`lineage_id` 表示来源脉络，不代表共享所有权。两个项目在同一 lineage 上可以有不同 item_id 和修订，不互相改写。

### 3.2 Requirement payload

```text
requirement_type: customer | market | product | regulatory | quality |
                  manufacturing | service | commercial
lifecycle: draft | active | rejected | obsolete
statement, rationale, priority
source_refs[], acceptance_intent
owner_user_id?, applicability
```

删除 `implemented / verified` 作为可写状态。实现和验证来自指定目标/Build/配置下的投影，不是 Requirement 的第二份真值。

`superseded` 表示某修订被后续修订替代的关系，不意味着整个需求永久废止；不得同时维护一套会互相矛盾的 item 状态与 revision 状态。

### 3.3 Specification payload

```text
parameter_key, title
value_type: numeric | categorical | textual
operator?, lower_bound?, upper_bound?, target_value?, unit?
tolerance?, conditions
verification_method_ref?, comparison_rule_ref?
acceptance_criteria, verification_phase?, criticality
source_requirement_refs[], rationale, assumptions
owner_user_id?, applicability
```

数值使用十进制精度与单位类型；`<= 85 °C`、`85 °F`、温升 `85 K` 不能按文本相似视为等价。工况、样本量、测量位置、峰值/均值口径均属于验证条件。

Specification 可以满足多个 Requirement；一个 Requirement 也可分解为多条 Spec。硬性来源约束不能因 ProjectOverlay 排除就自动变成不适用。

### 3.4 ProductDefinition payload

正式恢复此对象，不能只在迁移表中出现。

```text
purpose, use_cases, target_users, intended_markets
scope_in, scope_out
value_proposition?, product_concept
functional_structure, major_interfaces
industrial_design_direction?
commercial_targets?, constraints
assumptions[], unresolved_questions[]
requirement_set_refs[], specification_set_refs[]
```

它组织“做什么产品”的结构化定义，不再把规格数值复制一份。引用精确的需求/规格修订。正常方向为来源 → Requirement → ProductDefinition/Specification；定义变化可以发起 RequirementChangeSet，而不是静默反写需求。

### 3.5 Artifact payload 与专业工具

```text
artifact_type: drawing | cad_package | schematic | pcb_release | firmware |
               test_report | sop | wi | control_plan | fmea | certificate |
               prd_projection | specification_projection | other
origin_system, external_version_label?, source_commit?
files[{blob_ref, role}], manifest_digest
author_ref?, document_status_evidence?
related_content_refs[], compatibility_claims[]
```

原始工程文件是产物；PDOS 的抽取结构是受控镜像或解释。修改原文件应产生新 ArtifactRevision。对 CAD 内容没有解析能力时，保存文件和明确版本，不造内部几何结论。

`PRD/Spec` 导出保存 `ProjectionManifest(template_version, input_snapshot_id, generated_file_ref)`；外部编辑后重新导入为新证据，不默认更新结构化规格。

## 4. Project、Product 与投入状态

### 4.1 Project

```text
Project
  id, tenant_id, display_key, name
  project_type: customer_oem | new_product | derivative | cost_down |
                quality_improvement | compliance | technology_exploration
  status: active | on_hold | completed | cancelled | archived
  phase_key, phase_policy_version
  owner_user_id
  target_product_id?
  base_snapshot_id?
  crm_opportunity_ref?
  template_version_id
  version, created_at, updated_at
```

创建向导/导入暂存属于 IntakeRun，不引入长期 `Project.status=draft`。建立项目不要求已有产品基线或 CRM 商机；缺失关联必须显示，正式动作按政策补齐。

`Project.status` 与阶段、投入批准互相独立。`Exploring` 视图等于 `status=active AND phase_key=explore`，不增设 Exploring 状态。

### 4.2 ProjectCommitState 投影

以项目对应范围的有效 `project_commit` Decision 及其撤销、时限、条件事件计算：

```text
not_committed | committed | conditional | rejected | revoked | expired
```

不能只取“最新一条 Decision”，因为后续可能是局部增资、另一个范围的决定或撤销。必须按 `decision_type + scope_key + effective interval` 解析。

### 4.3 Product

```text
Product
  id, tenant_id, product_key, name
  lifecycle: candidate | active | retired
  product_line_ref?, parent_product_id?
  owner_scope_id
```

产品身份可以没有已发布技术基线。正式基线 head 由 `ProductReleaseLine(product_id, line_key, head_baseline_id, version)` 管理；正式发布随 V1 交付，首次实现只启用 default 线，V0 不要求先建发布线才能使用产品目录。某产品存在不等于允许采购/生产。

项目与产品是开发关系，不是同一对象：一个项目 V0 明确一个发布目标；复杂多产品发布后置，不能在单一 `product_id` 上暗做多产品更新。

## 5. Snapshot、基线与项目覆盖

### 5.1 Snapshot 及成员

```text
Snapshot
  id, tenant_id
  kind: import | evidence | project_baseline | product_baseline | context
  source_scope_id
  captured_at, manifest_digest

SnapshotMember
  snapshot_id, slot_key, content_kind, revision_ref
  applicability, provenance_ref?
```

同一快照内 `slot_key` 唯一。内容一经固定不改变；状态、撤销和使用资格由独立记录表达。Snapshot 不天然带批准含义。

### 5.2 ImportSnapshot

导入确认得到 `Snapshot(kind=import)`，并有 `ImportAcceptance(actor, accepted_items, missing_items, accepted_at, evidence_refs)`。含义是确认迁入现状，不是批准发布。旧批准证据可以单独登记 `HistoricalDecisionEvidence`，不得由导入日期推断。

### 5.3 ProjectOverlayEntry

```text
ProjectOverlayEntry
  id, tenant_id, project_id
  slot_key, content_kind
  operation: add | replace | exclude
  base_revision_ref?
  local_revision_ref?
  base_digest?
  reason_ref, created_by, version
```

规则：

- 继承未修改内容时不必复制整套对象，只在有效视图中读取锁定快照。
- `replace` 创建项目自有 ContentItem/Revision，保留 lineage 和来源；父产品修订不变。
- `exclude` 只对本项目生效，保留原因。客户/安全/法规等受控范围排除需对应决定，不自动绕过准备政策。
- `add` 使用新 slot，不能与已有 slot 冲突。
- overlay 指向完整修订，不用无止境 field patch 链表达最终事实。

```text
resolve(base_snapshot, overlays):
  effective = immutable_members(base_snapshot) or empty_set
  for each overlay sorted by stable slot:
    assert correct_base_and_permission
    apply add / replace / exclude
  return effective_members + provenance_map
```

解析结果可以缓存，但必须带 base/overlay digest。正式配置与决定使用物化的不可变快照，不在运行时读取“最新工作集”。

### 5.4 ProjectBaseline 与 ProductBaseline

| 对象 | 字段 | 含义 |
|---|---|---|
| ProjectBaseline | project_id、type、revision、snapshot_id、decision_id | 开发过程中某次被批准的范围、计划、定义等快照 |
| ProductBaseline | product_id、release_line_id、revision、snapshot_id、release_id、parent_baseline_id? | 被正式发布为某产品事实的技术快照 |

二者不是靠 `project_id? / product_id?` 猜含义。`ProductBaseline` 只有批准发布后才产生；待发布材料叫 ReleaseCandidate。`released/superseded/withdrawn` 由基线事件投影，不改基线内容。

某基线被新版本替代，不意味着旧批次及旧证据失效。是否适用于某批次由 effectivity 与配置范围决定。

### 5.5 发布、产品采用与三方冲突

`ReleaseCandidate` 保存源项目快照、目标 Product/发布线、意图 `new_product | update_product | derive_product`、预期 head、内容清单及 evidence digest。

批准后执行 `compose_product_baseline`：

1. 校验决定、内容/证据摘要、目标权限与当前 head。
2. 将需要发布的项目本地内容提升为目标产品拥有的修订，保存 `ContentPromotion` 映射和来源。
3. 同产品未修改的内容可继续引用原产品修订；派生产品采用内容时建立目标产品自己的采用记录/修订，不修改父产品。
4. 二进制文件不必物理复制，但对新目标受众的访问授权必须明确，不能借“继承”绕过权限。
5. 组装 ProductBaseline，使用 CAS 更新目标发布线 head，写事件与 outbox。

并行项目基于 B4 发布时：如果另一个项目已生成 B5，第二个不能直接覆盖 head。必须比较 `base / ours / current head`：无冲突可重新组装候选，冲突逐条裁决；实质变更后重新批准。历史 Build 和旧决定保留原快照。

`derive_product` 发布到新产品；父产品 head 不动。不得把每个客户派生都自动升成父产品新版本。

## 6. Configuration：Build 的可复现身份

### 6.1 ConfigurationSnapshot

```text
ConfigurationSnapshot
  id, tenant_id, project_id
  purpose: as_planned | as_built | as_tested | as_submitted
  predecessor_snapshot_id?
  product_baseline_ref?, project_baseline_ref?
  manifest_digest, created_by, created_at
  completeness: complete | partial | unknown
```

配置引用的内容一经生成不可变；新变化创建新快照，不更新旧 revision 指针。

### 6.2 ConfigurationEntry

```text
snapshot_id, slot_key
category: requirement_set | specification_set | bom | mechanical | electrical |
          firmware | software | material | tooling | fixture | process |
          sop | verification_method | test_equipment
revision_ref?, external_identifier?
actuality: confirmed | reported | unknown
applicability_scope
source_ref?
```

精确配置可以包括：图纸与结构件修订、PCB 制品、固件制品哈希、供应商/电池 pack 修订与批次、模具资产/模具修订/型腔/试模轮次、夹具修订、SOP/WI、测试设备与校准证据。

图纸版本和模具试次不是同一个字段。FW commit 是来源之一，不证明实际制品和烧录状态；测试时还应记录适用设置与设备。

### 6.3 ConfigurationEvent

```text
ConfigurationEvent
  id, tenant_id
  subject_type: unit | cohort
  subject_id, build_context_id
  event_type: assembled | material_replaced | firmware_flashed | reworked |
              fixture_changed | test_setup_recorded
  before_snapshot_ref?, after_snapshot_ref
  occurred_at?, recorded_at, time_certainty
  actor_ref, evidence_refs[], deviation_ref?
```

已装配样机临时换电池，不能改 Build 的计划快照；登记事件并创建新的实际快照。测试绑定测试开始时的快照。后补记录时间不确定时，不自动归到之前所有测试。

真实发生但未获授权的替换仍应允许保存原始证据、登记带未授权标记的实际事实，并触发异常与处置；不能因缺少 Deviation 批准而拒绝记录现实。记录发生过什么不等于批准这项变化或允许继续执行。

### 6.4 Cohort、Unit 与重复使用

- `Cohort`：同轮中可证明相同配置的一组样机；混料后必须拆分或细化到 Unit。
- `Unit`：有长期标识的样机，保存 `origin_build_id`；不是只能参加一轮。
- `BuildParticipation`：Build 与 Unit/Cohort 的关系，角色为 `created | reworked | evaluated`，可关联前轮样机。

重测原样机不必新建 Build；改变制造配置并有新的实验/装配目的时可创建新轮次。原来的出生配置和每次变化均保留。

## 7. Build、准备、交接与本轮处置

### 7.1 Build 聚合

```text
Build
  id, tenant_id, project_id, display_key
  build_type: sample | prototype | evt | dvt | trial | pvt | pilot | ramp
  purpose, questions_to_answer[]
  target_quantity?, quantity_unit?
  planned_configuration_ref?
  predecessor_build_refs[]
  owner_user_id
  readiness_policy_version_id
  target_window?, schedule_node_id?
  manufacturing_status: planning | authorized | in_progress | manufactured | cancelled
  version
```

状态转换：

```text
planning → authorized → in_progress → manufactured
planning / authorized → cancelled
in_progress → cancelled（记录已产出与未完成处置）
```

停等使用 `BuildHold` 记录原因、范围、开始/解除，不抹去制造状态。调整已授权的关键配置使授权不再适用时，必须冻结新候选并重新授权；不能直接换指针。

`manufactured` 只表示本轮制造范围已处置完毕，不能推导测试通过、客户承认或生产放行。

### 7.2 BuildDisposition

```text
BuildDisposition
  build_id, evidence_snapshot_id, decision_ref?
  outcome: continue_next | rework | retest | abandon | ready_for_gate
  unresolved_issues[], accepted_conditions[], next_actions[]
  actor, recorded_at
```

本轮结束必须说明发现、接受/拒绝的变化和遗留风险。“所有 Work Done”不足以生成处置结论。

### 7.3 SampleHandoff 与队列

```text
SampleHandoff
  id, build_id, unit_or_cohort_refs[]
  from_party, to_party, purpose
  actual_configuration_refs[]
  required_manifest_refs[]
  requested_return_window?, receiver_commitment_ref?
  status: preparing | offered | needs_completion | accepted |
          scheduled | in_test | returned | cancelled
```

`HandoffEvent` 分别记录样机实物到达、文件齐套、接收人确认、退回缺项、预约测试、开始、回传。品质排期承诺以外部/共享资源承诺进入排程，不在任务估工里隐藏。

交接等待度量以这些事件计算：从“资料与实物均可用”到接收/排程/回传；不得把未交齐资料的等待误计成品质拖延。

### 7.4 Work 的定位

```text
Work
  id, project_id, type, title
  owner_user_id?, recipient_user_id?
  status: backlog | ready | in_progress | blocked | submitted | done | cancelled
  deliverable_refs[], completion_criteria
  estimate?, external_wait_ref?
  version
```

`WorkBuildLink` 允许一个 Work 支撑多轮 Build；研究可无 Build。专业结果需要接收时使用 `submitted`，不能将上传文件自动当作接收完成。

工时和等待不重复维护：等待有 ExternalCommitment/排程节点时，Work 仅引用；legacy `wait_days` 迁移成有单位和依据的 PlanEstimate，不再作为第二个权威交期。

## 8. Verification：原始值到正式证据

### 8.1 VerificationPlan / VerificationRun

VerificationPlan 为版本化内容：Spec 修订、方法、条件、样本量、样机配置范围、设备要求、数据口径、比较规则、结果处置和责任人。

```text
VerificationRun
  id, tenant_id, project_id, build_context_id
  plan_revision_ref
  unit_or_cohort_refs[]
  as_tested_configuration_ref
  state: planned | ready | running | recorded | cancelled
  started_at?, ended_at?
  evidence_refs[]
```

运行状态不是结果；`recorded` 不等于 PASS。同一 Build 可以有多次 Run，重测必须能区分前后原因。

### 8.2 ObservationCandidate 与 ObservationSet

LLM 抽取只创建 `DraftProposal(kind=measurement)`，其中保存候选观测：原始数值/文本、单位、字段语义、来源定位、条件、配置匹配建议与不确定性。

确认后创建不可变 `ObservationSet`：

```text
ObservationSet
  id, verification_run_id
  rows[{parameter, raw_value, raw_unit, normalized_value?, normalized_unit?,
        statistic_type?, condition_refs, source_ref}]
  source_digest, schema_version
  measurement_review_id
  supersedes_observation_set_id?
```

### 8.3 MeasurementReview

```text
MeasurementReview
  id, tenant_id
  observation_payload_digest
  configuration_ref, method_ref, spec_ref, rule_ref
  evidence_refs[], source_binding_digest
  review_mode: human_confirmed | trusted_structured_ingest
  reviewer_actor, policy_version, confirmed_at
  exceptions[], rejected_fields[]
```

确认包包含数值、单位、峰值/均值、样本、工况、方法、配置和规格映射，不只确认数字。

结构化导入只有在来源身份、schema、配置映射、设备/校准要求、文件完整性和受控规则都通过时，才可由系统主体 S 形成记录。CSV 格式固定本身不够；任何依赖 LLM 判断的关键映射仍须 A1。

### 8.4 ComparisonRule 与 CalculationResult

```text
ComparisonRule
  id, revision, input_schema
  formula_or_predicate, unit_policy, rounding_policy
  required_conditions, sample_policy
  approved_by, digest

CalculationResult
  id, verification_run_id, observation_set_id
  spec_revision_ref, comparison_rule_revision_ref
  engine_version, input_digest
  result: pass | fail | unknown | not_run
  computed_values, missing_inputs[], reasons[]
  calculated_at
```

结果只由确定性引擎生成。单位不明、方法不匹配、样本不够、条件缺失或配置未知时不能输出用于放行的 PASS。无法数值化的外观、手感等判据使用具名的 `ManualAssessment`，其结果不伪装成模型计算。

### 8.5 VerificationDisposition 与适用性

```text
VerificationDisposition
  verification_run_id, result_ref
  disposition: accepted_evidence | rejected_evidence | retest_required
  actor, rationale, applicability_scope, evidence_refs
```

接受证据可能是接受一份 FAIL 报告，不等于批准产品。报告作者写“PASS”可以记录为来源主张，与内部规则计算及工程处置分开。

`EvidenceApplicability` 记录报告/结果适用于哪些 Spec 修订、配置、市场、样本和方法。派生项目不因“元件未变”自动复用全部证据。

### 8.6 更正与传播

更正值新建 ObservationSet、CalculationResult；旧记录保留。将曾引用旧结果的投影标记 stale，创建复核事件。历史 Decision 的证据快照不变；当前继续执行资格需根据新事实评估，不能自动宣称历史签字被撤销，也不能继续无提示地使用旧 PASS。

### 8.7 Requirement 投影

`ImplementationProjection` 表示关联交付证据与工程处置的情况，不以任务完成率直接等同实现。

`VerificationProjection` 的键至少包含：需求修订、目标产品/项目、选定 Build/配置、政策版本。

状态：`unplanned | planned | in_progress | partial | passed | failed | unknown`。任何必需项明确失败显示 failed；缺失范围不显示全通过。偏离获准作为独立 `waiver` 标识，不把 FAIL 改成 PASS。旧失败导致的问题未关闭时，不能用一次新 PASS 隐藏问题。

## 9. Decision 与承诺点

### 9.1 Decision 通用基础设施

```text
Decision
  id, tenant_id, project_id
  decision_type, scope_key
  question, options[]
  policy_version_id
  evidence_snapshot_id, evidence_digest
  state: draft | in_review | decided | withdrawn
  outcome?, conditions[], effective_from?, effective_until?
  version

DecisionResponse
  decision_id, participant_actor, authority_role
  response, signed_evidence_digest, responded_at
```

`decision_type` 至少覆盖 `project_commit / definition_baseline / build_authorize / change_approve / commitment_authorize / customer_submission_authorize / customer_approval_record / product_release / manufacturing_release / risk_acceptance`。

Outcome 使用对应政策允许的枚举，例如批准、附条件批准、不批准、补证；不强迫每个决定使用相同的业务含义。

决定后发现问题使用撤销、替代或复核事件，不能改原签字和原证据。Approval policy 自身也必须版本化，不能修改模板后悄悄改在途要求。

### 9.2 不保留隐藏人工执行链

`authorize_build` 可以在一个本地事务中保存最终决定、冻结计划/配置、记录授权和激活对应 Work；不能随后再要求新的“执行申请批准”和“独立应用确认”。

必要的责任承接放在本决定的可见条件中。不同职责的真实签署可以在同一证据包中完成；减少界面操作不等于伪造他人签名。

### 9.3 CommitmentPoint

```text
CommitmentPoint
  id, tenant_id, project_id
  type: id_freeze | mechanical_freeze | tooling_release | steel_cut |
        long_lead_order | pcb_fabrication | lab_submission |
        golden_sample | pilot_material_release | other
  kind: scope_freeze | physical_or_financial_commitment
  subject_snapshot_ref, affected_build_refs[]
  policy_version_id, planned_window?
  authorization_decision_ref?
  reversibility_notes, exposure_item_refs[]
```

追加 `CommitmentPointEvent`：`proposed / authorized / freeze_activated / executed / cancellation_requested / cancelled_before_execution / reversal_recorded`，带事件证据、发生时间和主体。

- 范围冻结可在批准事务中激活，但必须明确冻结范围。
- 批准开模后，只有实际切钢/外部执行证据才标记已执行。
- 已发生动作不能被“取消”从历史抹掉；后续退货、改模、赔偿是补偿事件。
- CommitmentPoint 与 G0 项目投入状态不是同一字段。

### 9.4 ExposureItem

```text
ExposureItem
  commitment_point_id?, change_id?
  category: tooling | material | lab | logistics | rework | other
  amount?, currency?, quantity?, unit_cost?
  basis: actual | binding_quote | supplier_quote | engineering_estimate | unknown
  source_ref?, valid_until?
  included_cost_refs[], cancellation_terms_ref?
```

变更评估区分已发生沉没支出、不可撤回剩余义务和新增修改成本；不能把订单总额、返工报价和包含返工的总报价重复相加。币种转换需要明确汇率来源和日期，缺失则不汇总。

## 10. ExternalCommitment 与排程约束

### 10.1 ExternalCommitment

```text
ExternalCommitment
  id, tenant_id, project_id
  party_ref
  party_type: supplier | lab | customer | logistics | internal_shared_resource
  deliverable_ref, related_build_refs[]
  owner_user_id
  required_event_type, required_by?
  current_revision_id
  status: open | fulfilled | cancelled | disputed
```

外部共享资源包含品质实验室、试产线等内部共享槽位。“External”在此指不由当前 Work 自己决定的供给或承诺，不限定企业外部。

### 10.2 ExternalCommitmentRevision

```text
id, commitment_id, previous_revision_id?
event_type: dispatch | arrival | sample_ready | trial_complete |
            service_start | result_return | approval_reply
promised_window_start?, promised_window_end?
date_precision: exact_time | date | window | unknown
timezone?, calendar_ref?
evidence_level: reported | acknowledged | formal_record
source_ref, source_claim_ref?
confirmed_by, confirmed_at
```

`reported/acknowledged/formal_record` 是证据层级，不是兑现概率。模型输出 confidence 不进入正式履约概率字段。

“没有对方承诺，只是我们预计”存 `PlanEstimate`，不能伪造 ExternalCommitmentRevision。`ActualDeliveryEvent` 记录实际发运/到达/检验放行，保留原承诺历史。

### 10.3 相对日期和日期口径

“下周五”“月底左右”“周四发、周五到”先保存在 SourceClaim。来源时间、发送方时区、发运/到达语义或工作日口径不明确时，不能直接写正式日期。

确认承诺变更只更新预测输入，不改批准基线。正式采购订单信息以 ERP 引用为准；普通供应商消息不自动改变 PO。

### 10.4 ScheduleNode、Dependency、Calendar 与资源

```text
ScheduleNode
  id, project_id
  node_type: work | external_event | build | verification | commitment_point |
             receipt_check | transport | milestone | resource_slot
  object_ref
  duration_estimate_ref?, calendar_ref, required_resource_refs[]

ScheduleDependency
  predecessor_node_id, successor_node_id
  relation: FS | SS | FF | SF
  lag_value, lag_unit: working_hour | working_day | calendar_day
  lag_calendar_ref
  logic_group: all_required | selected_alternative
```

`Calendar` 包含工作时段、节假日、时区和版本；`ResourceBooking` 保存品质测试、模具试模、实验室/产线的已确认槽位与证据。V0 使用简单、明确的共享资源槽位，不承诺复杂多项目最优排程。

`PlanEstimate` 保存持续时间/运输时间/检验时间的值或区间、来源、确认者和版本，不能由 AI 静默修改正式计划。

### 10.5 确定性计算规则

对于最常见的全部前置满足情形：

```text
available_at(input) = 对应事件日期
ready_at(input) = 按口径追加必要运输/收料/检验时间后的日期
build_earliest_start = max(all required ready_at, selected line/resource slot)
forecast = 在日历与持续时间规则下计算后续节点
```

注意：

1. 已知“到达日期”不再重复加运输天数；“发运日期”必须考虑运输及收料。
2. AND 前置取全部约束；替代供应方案必须被明确选择，不能直接取最早日期。
3. 输入为时间窗口时输出窗口/场景，不伪造精确一天；关键输入未知则输出相应未知与假设清单。
4. 工时、等待、检验和客户确认分节点或有明确语义，不用一个 wait_days 隐藏一切。
5. 模具返工不能在 DAG 中形成回边。T1→整改→T2 表示新的 TrialAttempt 和新的节点。
6. 检测依赖循环、日历缺失、资源冲突和无法达到的硬窗口；不能给出貌似精确的日期掩盖不可行。

### 10.6 ScheduleScenario 与 ScheduleBaseline

`ScheduleScenario` 保存引擎版本、所有输入及日历摘要、所用估计、输出日期/窗口、关键路径和未知项。`ScheduleForecast` 是当前有效场景的投影指针。

批准的日期集合固定在 ProjectBaseline 的计划快照中，可在 UI 称为 ScheduleBaseline，不再另设可变基准日期字段。外部延期只使 forecast 漂移；改基准需新决定。

## 11. BuildReadiness 与 ManufacturingReadiness

### 11.1 ReadinessPolicy

```text
ReadinessPolicyVersion
  id, purpose: build_start | build_disposition | manufacturing_release
  project/build types, applicability
  criteria[{criterion_key, subject_selector, required_evidence_type,
            rule_ref?, severity: hard | conditional | informational,
            freshness?, allowed_exception_policy?}]
  approved_by, digest
```

`PolicyEvaluation` 保存当前快照、规则结果、证据与新鲜度。对无数值规则的专业判断要求具名 `ManualAssessment`，不让 LLM 生成满足结论。

### 11.2 聚合逻辑

每条 criterion 为 `satisfied | unsatisfied | unknown | not_applicable`。

建议聚合：

- 任一不能豁免的 hard 条件 unsatisfied → `blocked`。
- 无明确失败，但关键 hard 证据缺失/过期/无适用性 → `unknown`，不当作 ready。
- 满足所有 hard 条件，剩余条件有有效、限定范围的授权 → `ready_with_conditions`。
- 全部适用必备条件满足 → `ready`。

排程风险 `on_track / at_risk / late / unknown` 独立展示。准备率如需显示，只是可展开的满足数量统计；不能平均后放过关键失败。

### 11.3 探索性 Build 与量产准备必须不同

一轮为解决热问题的实验样机不要求此前热问题已经通过；它需要受控实验协议、安全限制、适用夹具和明确人员。正式制造/出货则按更严格的验证和放行政策。

风险接受不能绕过不可豁免的要求。偏离有范围、时限、批次和批准人，使用 `Deviation`，不能伪造 PASS 或批量 N/A。

## 12. Issue、Change 与闭环

### 12.1 Issue

```text
Issue
  id, project_id, title, problem_statement
  source_refs[], observed_build_refs[], unit_or_cohort_refs[]
  observed_configuration_refs[]
  severity, owner_user_id
  state: open | triaged | investigating | actioning | awaiting_verification | closed
  closure_evidence_refs[], version
```

AI 疑点先存 DraftProposal，不进入正式问题统计。可信结构化测试失败可以按受控 S 规则建单，但规则必须版本化、可去重、有明确责任范围。

根因假设与已证实根因分开。Issue 关闭需满足问题自己的验证与处置标准；一个 Work Done 或单份新 PASS 不足以自动关闭。

### 12.2 Change

```text
Change
  id, tenant_id, project_id
  title, reason, source_refs[]
  scope: product | process | both
  state: draft | assessing | in_review | approved | implementing | verifying |
         closed | rejected | cancelled
  affected_slot_refs[], affected_build_refs[]
  impact_snapshot_ref?, decision_ref?
  owner_user_id, version
```

影响数据分为：确定图关系、人工专业判断、AI 建议。只有已确认的关系进入正式影响范围；AI 建议完整性不足时明确显示“待专业复核”。

### 12.3 ChangeImpactAssessment

至少包括 Requirement/Spec、图纸/PCB/FW、BOM、SOP/夹具、验证、客户承认、认证适用性、已跨 CommitmentPoint、ExternalCommitment 与排程/成本。

每个影响项记录 `known | suspected | no_impact_confirmed | unknown`、证据、评估人和所用基线。不能把“AI 没检索到影响”显示为“无影响”。

### 12.4 ChangeImplementation 与验证

`ChangeImplementation` 记录变更在具体内容修订、配置、Build、产品发布或 ERP 生效中的实施证据。批准不等于实施，实施不等于验证。

`ChangeVerificationLink` 指向本次要求的验证计划/Run/Disposition。关闭时检查范围、结果、残余问题与必要客户重新承认。若变更只在一个客户型号生效，不自动关闭其他型号上的原问题。

### 12.5 Deviation

```text
Deviation
  project_id, build/unit/config scope
  violated_or_unmet_requirement_refs[]
  permitted_action, constraints, valid_until
  decision_ref, verification_required
  state/events
```

偏离可以允许特定试验或批次的有限动作，不改变规格、不删除失败结果、不等于外部法规豁免。

## 13. 客户提交、反馈与承认

### 13.1 CustomerSubmission

```text
CustomerSubmission
  id, project_id, customer_ref, recipient_refs[]
  purpose, submission_scope
  as_submitted_configuration_ref
  unit_or_cohort_refs[], artifact_revision_refs[]
  requested_response_window?
  authorization_decision_ref
  dispatch_state: draft | authorized | sent | delivered | cancelled
  dispatch_evidence_refs[]
```

状态必须以相应事实推进。已授权不等于已发出；快递签收也不等于客户承认样品。

### 13.2 CustomerFeedback

```text
CustomerFeedback
  id, project_id, source_ref
  submission_ref?, build_ref?, customer_actor_ref?
  received_at, original_content_ref
  interpretation_items[]
  handling_state: unreviewed | clarified | routed | resolved
```

解释项可以指向需求、外观、包装或性能，但必须保留原文及不确定性。反馈可产生 Change 候选，不能直接更新规格。

### 13.3 CustomerApproval

```text
CustomerApproval
  id, project_id, submission_ref, customer_ref
  customer_actor_ref, actor_authority_evidence?
  scope_items[{subject_ref, scope_type: appearance | color | performance |
               packaging | drawing | specification | sample | golden_sample}]
  outcome: approved | approved_with_conditions | rejected
  conditions[], customer_occurred_at?, recorded_at
  source_refs[], recording_decision_ref
```

待确认回复保留为候选，不预先建立 approved 记录。具名内部人员按政策核实联系人、对象版本、条件和范围后登记正式承认，采用 A2 或直接人工正式记录动作。它是对客户决定的取证登记，不是内部替客户批准。

撤回和替代用新事件。颜色获承认不推导整机性能获承认；改了所承认的版本，应显示需重新确认的范围。

### 13.4 GoodJob 映射

CRM 真值维持其 Lead/Opportunity 模型。`crm_opportunity_ref` 关联商机；RFQ 为 SourceEnvelope 中的材料组，不在 PDOS 或 GoodJob 擅自加 Inquiry 层。

销售的线索转化、身份确认、赢单与报价继续在 CRM 规则内。客户技术反馈可以在两个系统中显示，但通过 SourceRef/ExternalObjectLink 保持一个原始来源和处理回执。

## 14. 产品工艺两条线与试产

### 14.1 ProcessDefinition

作为 ContentRevision：

```text
process_purpose, product/config applicability
operations[]
required_assets[], controlled_document_refs[]
quality_control_refs[], safety_notes
```

V0 仅覆盖本轮必要操作、SOP/WI 和夹具引用；V1 补全过程准备。

### 14.2 Operation

```text
operation_key, sequence/predecessor_keys
name, input_refs[], output_refs[]
station_ref?, equipment_refs[], fixture_refs[]
sop_revision_refs[], wi_revision_refs[]
quality_check_refs[], skill_requirements[]
cycle_time_definition?, target_cycle_time?
```

该对象表达开发/试产用受控工艺定义，不接管 MES 工序报工和库存。SOP 必须绑定本轮实际采用的修订，不能只链接一个“最新 SOP.pdf”。

### 14.3 ManufacturingAsset 与 TrialAttempt

`ManufacturingAsset` 是模具、夹具、量检具、测试治具或设备的引用身份，包含内部/外部资产号、类型、维护方和可追溯修订。

`AssetAcceptance` 记录该修订在某条件下的验收、缺陷和适用性；“采购到货”不等于通过验收。

`TrialAttempt` 记录 T0/T1/T2 等具体试次：工具/模具资产及修订、型腔、设置、目的、日期、样品、观察、整改项和验收证据。T2 是试次标签，不自动推断工具设计改了两版。

试模由技术发起；工程负责其设备/模具/工装职责，生产负责实际调机与样品产出，品质按明确交接资料和槽位进行验证。具体负责人在项目中绑定，不硬编码独立工艺部。

### 14.4 培训、过程控制与试产指标

- `TrainingEvidence`：人员/岗位、SOP 修订、培训时间、考核/确认来源；不简单从任务完成推导已具备资格。
- PFMEA、控制计划等可以先作为受控 Artifact 与 Operation 关联，后续再增加结构化深度。
- `PilotRunMetrics`：投入数量、首次检验通过数、返修、报废、待处置、节拍样本、数据口径与来源。

例如 FPY 的计算必须固定“首次通过数 / 进入所定义首次检验范围的数量”；返修后通过不能计入首次通过。分母、排除样本、返修和报废定义必须随指标保存，不能按漂亮数字填报。

## 15. Certification 与适用性

### 15.1 CertificationCase

```text
id, tenant_id, project_id?, product_ref?
market, certification_or_test_program
standard_name, standard_edition, authority_source_ref?
subject_configuration_scope
owner, lab_ref?
state: assessing | planned | submitted | testing | evidence_received | closed | cancelled
external_commitment_refs[], evidence_refs[]
```

可写录入某标准名称，不代表系统已确认其法律适用性。标准版本、试验要求和认证范围需从有权威的来源及具备职责的人确认；本文不指定某款产品必须获得哪项认证。

### 15.2 CertificationEvidence / CertificationRequirementLink

证据区分测试报告、正式证书、供应商声明、实验室邮件。保存签发主体、报告/证书号、覆盖型号/配置/工厂、有效期信息（若有）、限制条件与原文件。

`CertificationRequirementLink` 连接经确认的认证要求与 Requirement/Spec；`EvidenceApplicability` 连接证据与目标配置。没有到期日不自动推断永久有效；没有检索到影响不等于变更后仍适用。

V0 用于显示要求、证据与缺项；V1 支持制造放行前的完整适用性审查与实验室承诺。

## 16. 研发 BOM、发布与 ERP 交接

### 16.1 DevelopmentBOM

版本化内容包含行号/稳定行标识、料件引用、数量/单位、候选替代、供应商、价格来源、临时料号/ERP 料号/客户料号及对应关系。

BOM Delta 使用相同的锁定来源与项目本地变化原则。适用版本、替代规则和实际使用的物料批次仍通过 Configuration 明确；候选 BOM 中的替代不等于样机实际替换。

V0 可以仅挂接 BOM 文件与关键料件行；完整结构和交接在 V1，平台 Delta 体验在 V2。

### 16.2 ProductRelease 与 ManufacturingRelease

产品发布是生成目标 ProductBaseline；制造放行是允许指定配置、工艺和适用范围进入制造的决定。可以在同一次业务评审中办理，但仍是两个明确效果。

制造准备证据可包含产品基线、过程定义、工装/夹具验收、SOP/培训、验证、认证、供应、试产和未关闭偏离。该清单由产品和项目类型政策配置，不是对所有企业的强制标准。

### 16.3 HandoffPackage / HandoffAttempt

```text
HandoffPackage
  id, source_product_baseline_ref
  manufacturing_release_decision_ref
  target_system, target_scope
  mapping_manifest, payload_digest
  expected_target_version?

HandoffAttempt
  package_id, idempotency_key, attempt_no
  state: queued | sent | acknowledged | accepted | applied | rejected | unknown
  external_receipt_ref?, external_effectivity_ref?
  error, recorded_at
```

`acknowledged` 仅表示收到，`accepted` 表示目标系统接纳包，`applied` 才表示权威生效回执。部分失败逐项记录，不能显示整个交接已生效。

本地事务无法与 ERP/消息系统构成可回滚的单一数据库事务。使用 outbox、幂等、对账与补偿；响应超时先核查目标状态，不盲目重复执行可能不可逆的外部动作。

PDOS 不生成采购付款、库存扣减或实际生产执行事实。ERP 料号绑定失败时进入映射队列，不擅自新建正式料号。

## 17. Intake：冷启动与在途迁入的正式模型

### 17.1 IntakeRun

```text
IntakeRun
  id, tenant_id
  intake_type: new_oem | existing_project | historical_product
  target_scope_ref?, source_envelope_ref
  parser_versions[], mapping_template_version?
  state: received | parsing | review_required | ready_to_apply | applied |
         failed | cancelled
  version
```

`SourceEnvelope` 是本次提交的材料组：多个 SourceRef、提交者、原始渠道、接收时间、业务提示。它不自动创建正式客户、项目或需求。

### 17.2 ExtractionRecord 与 MappingProposal

```text
ExtractionRecord
  intake_run_id, source_ref, locator
  raw_value, raw_unit?, interpreted_value?
  field_semantics, extraction_method
  uncertainty_flags[], parser_or_model_version

MappingProposal
  extraction_refs[], proposed_object_kind
  target_scope_ref?, target_object_ref?
  action: create | append_revision | link | ignore
  duplicate_candidates[], conflicts[], unresolved[]
```

按值对象保存也可，但所有需确认字段都必须可追溯到精确来源。PDF/图片的识别不能因“解析成功”就升级成已确认事实。

### 17.3 AcceptanceBatch 与应用

```text
AcceptanceBatch
  intake_run_id, selected_proposals[]
  target_versions[], source_digest
  confirmed_by, confirmed_at
  confirmation_scope, unresolved_items[]
```

`apply_intake_batch` 在本地事务中进行幂等写入并生成映射回执。大批次按清楚的子批次提交，界面显示哪些已应用、哪些未应用；不能把跨多个事务的批量操作宣传为全量原子。

V0 导入新项目时可只确认当前必需字段，未知项进入缺项视图。历史产品导入产生 ImportSnapshot；旧排期只作来源/估计，旧“已完成”列不能生成虚假签名或 PASS。

### 17.4 重复与冲突

重复文件用同租户内容 hash 辅助识别；同一内容被不同客户或项目引用不等于重复业务对象。文件名相同但内容不同必须作为新修订候选。

优先级不按文件时间戳简单裁决。新版规格、客户批准图纸、BOM 可能互相冲突；由明确内容责任人与证据政策确认，不由 AI 自动选“看起来最新”的版本。

### 17.5 责任与权限迁入

旧表中的名字映射到当前用户需要确认，尤其同名、离职、外部参与者。确认“历史由某人负责”不赋予该人当前系统权限，也不等于当前责任已承接。

## 18. Agent 与候选对象的落点

详细执行规则见 03。本节给出数据引用，避免领域模型出现无定义的 AI 对象。

| 对象 | 核心字段 | 权威性 |
|---|---|---|
| CapabilityVersion | key、输入/输出 schema、工具白名单、事件订阅、策略、版本 | 经平台配置批准的能力定义 |
| AgentRun | capability_version、trigger_ref、scope、input_snapshot、状态、模型与耗用、回执 | AI 运行事实 |
| ToolCallReceipt | run_id、工具、经脱敏的参数摘要、结果引用、拒绝原因 | 工具调用审计 |
| DraftProposal | run_id、proposal_kind、目标、候选 payload、来源、预期版本、风险等级、状态 | 未确认前不是业务事实 |
| ProposalConfirmation | proposal_digest、用户、目标版本、决定/动作范围、时间 | A1 人工确认记录 |
| AIAnnotation | run_id、目标、摘要/标签/建议链接、generated_at、expires_at? | 非权威信息 |
| ContextSnapshot | 所取来源/版本、授权范围、摘要、取数时点 | 输入复现，不授予额外权限 |
| AgentFeedback | 接受/修改/拒绝、原因、最终业务结果引用 | 评估输入，不自动改企业规则 |

`DraftProposal.kind` 可为 requirement_changeset、measurement、configuration_update、issue、external_commitment、customer_feedback_interpretation、change_impact 等。无需为每类候选建立一个全新的业务模块。

所谓 IssueCandidate 就是 `DraftProposal(kind=issue)`；RequirementChangeSet 是一批需求变更候选及其确认事务，不再绑定唯一 `source_definition_ref`。

DraftProposal 状态为 `prepared | pending_review | accepted | applied | rejected | withdrawn | stale | failed`。accepted 与 applied 可表达确认和后台提交的技术分界，但 UI 只提供一次有意义的确认；不得由这两个状态重新长出“用户再应用一次”的隐藏流程。确认后版本变化进入 stale，必须重新审阅；重试同内容的幂等提交不要求重复确认。

## 19. 事务、命令与事件

### 19.1 通用写命令信封

下列为新目标 API 契约，不声称当前已有这些端点：

```json
{
  "command_id": "UUID",
  "idempotency_key": "tenant-scoped-key",
  "target": {"kind": "build", "id": "UUID", "expected_version": 7},
  "payload_digest": "sha256:...",
  "source_refs": [],
  "confirmation_ref": "UUID-or-null",
  "payload": {}
}
```

`tenant_id`、actor、授权 scope、动作等级由服务端身份和领域对象推导，不能信任客户端或模型自报。服务器重新计算 payload digest。

### 19.2 关键命令

| 命令/建议端点 | 重要前置 | 本地事务效果 | 不应发生的副作用 |
|---|---|---|---|
| `POST /intakes/:id/apply-batch` | 来源、确认、目标版本有效 | 内容修订、映射、回执 | 不补历史批准、不自动外发 |
| `POST /projects` | 最小权限和字段 | Project 与成员责任 | 不要求 Case、不替 CRM 转化线索 |
| `POST /projects/:id/requirement-changesets/apply` | A1 确认或直接人工编辑、差异有效 | 新修订与 overlay | 不改旧基线 |
| `POST /configurations/freeze` | 明确配置范围、策略与签名 | 不可变配置快照 | 不把计划当实际 |
| `POST /builds/:id/authorize` | 同证据摘要、必备条件/响应满足 | 决定、授权与固定输入 | 不伪造生产开始 |
| `POST /units/:id/configuration-events` | 实际变化、时间与权限 | 新事件/实际快照 | 不重写过去测试 |
| `POST /handoffs/:id/accept` | 样机及资料可接收 | 接收事件、排程需求 | 不自动测试通过 |
| `POST /observations/confirm` | A1 或可信 S、完整确认包 | ObservationSet/Review、计算事件 | 未确认数据不进 Gate |
| `POST /external-commitments/:id/revisions` | 有来源、日期口径清楚 | 承诺新修订、预测重算事件 | 不改批准计划/ERP PO |
| `POST /decisions/:id/respond` | 角色授权、证据未变 | 本人响应及可能的定稿 | 不代签其他参与者 |
| `POST /releases/:id/compose` | A2、目标 head CAS、采用权限 | 产品修订映射、新基线、outbox | 不代表 ERP 生效 |
| `POST /handoff-packages/:id/dispatch` | 已授权版本、映射有效 | outbox 与发送任务 | 不将超时当成功 |

### 19.3 领域事件信封

```text
event_id, tenant_id, event_type
aggregate_kind, aggregate_id, aggregate_version
occurred_at, recorded_at
actor_type: human | ai | system | external
actor_id, correlation_id, causation_id
payload_schema_version, payload_ref/digest
```

本地事务写业务数据和 outbox。订阅者按 event_id 和版本去重，不承诺分布式 exactly-once。旧版本事件不能覆盖较新状态；顺序不明时重读权威聚合。

关键事件包括：

```text
intake.batch_applied
project.created
content.revision_created
configuration.frozen
unit.configuration_changed
build.authorized
build.started
build.manufactured
handoff.accepted
handoff.returned
observation.confirmed
observation.corrected
verification.calculated
verification.disposition_recorded
external_commitment.revised
commitment_point.executed
customer_submission.sent
customer_feedback.recorded
customer_approval.recorded
change.approved
change.implemented
decision.decided
product_baseline.released
erp_handoff.applied
```

### 19.4 影响与失效传播

`ProjectionDependency` 记录哪个投影/候选/决定准备包依赖哪些修订、规则和来源。来源更正后：标记投影 stale → 重算 → 输出差异 → 必要时发起复核。

必须区分两类变化：来源新增普通修订只提示“有新版本可比较”，不自动使锁定的旧快照失效；来源被正式更正、撤回，或当前适用性被确认失效，才触发相应的证据复核。否则每次工程师保存文件都会错误地使全部批准过期。

不能删除已签决定以“修正状态”；也不能把曾经批准的执行范围自动扩展到新配置。

## 20. 数据库与服务不变量

| 编号 | 不变量 | 建议保障方式 |
|---|---|---|
| INV-01 | 跨租户引用不成立 | 复合外键/服务校验/RLS，查询层与存储层双重约束 |
| INV-02 | ContentItem 仅一个拥有作用域 | 非空 owner_scope_id 与唯一归属关系 |
| INV-03 | Revision/Snapshot 内容不可变 | 写接口只允许新增；数据库角色禁止更新正文 |
| INV-04 | Product/Project 基线不同且无导入伪批准 | 明确表/类型约束及不同创建命令 |
| INV-05 | 项目 overlay 不更新源修订 | 本地 item/修订、来源引用、禁止跨所有者原地更新 |
| INV-06 | 同目标发布 head 并发受控 | CAS/事务锁与 expected_head，冲突不静默覆盖 |
| INV-07 | 一个历史测试绑定确定实际配置 | VerificationRun 持久化 as_tested 快照与时间证据 |
| INV-08 | 未确认观测不能用于正式计算/Gate | 计算输入必须有有效 MeasurementReview |
| INV-09 | 比较规则与样本条件缺失不产生有效 PASS | 引擎验证输入与适用性政策 |
| INV-10 | 承诺、预测、批准基准互相不覆盖 | 分对象/版本存储，UI 显式口径 |
| INV-11 | A0 不能修改权威业务状态 | 独立 AI 身份、工具白名单和提交层策略 |
| INV-12 | 客户承认不等于内部放行 | 不同对象与决定，禁止隐式状态联动 |
| INV-13 | 已执行承诺不可“撤销历史” | 追加事件和补偿记录 |
| INV-14 | 原子性只涵盖同一本地事务 | outbox、外部回执与对账机制 |
| INV-15 | 同一幂等键相同 payload 返回同一结果 | 唯一约束；不同 digest 返回冲突 |
| INV-16 | 复用来源权限不自动扩散 | 显式采用/发布授权与检索级权限过滤 |
| INV-17 | 准备度由规则与证据推导 | 不开放 ready/percentage 的任意写 API |
| INV-18 | 没有历史数据也能建首轮 | base_snapshot 可为空，Intake 模板只作候选 |

多态引用必须通过可校验的对象注册/类型化外键或领域服务进行完整性校验；不能只有 `kind + uuid` 字符串而没有存在性与租户约束。实现选择应在数据库设计审查中明确。

## 21. 错误码与可恢复性

建议错误码：

```text
VERSION_CONFLICT
IDEMPOTENCY_DIGEST_MISMATCH
SOURCE_UNAVAILABLE
SOURCE_SCOPE_DENIED
CONFIGURATION_INCOMPLETE
CONFIGURATION_CHANGED_AFTER_AUTHORIZATION
OBSERVATION_UNCONFIRMED
VERIFICATION_CONTEXT_MISMATCH
READINESS_HARD_BLOCKER
DECISION_EVIDENCE_STALE
APPROVAL_AUTHORITY_MISSING
RELEASE_HEAD_MOVED
INHERITANCE_CONFLICT
EXTERNAL_EFFECT_UNKNOWN
IMPORT_MAPPING_CONFLICT
```

错误必须附当前可见版本、可操作缺项或重审入口，不泄露无权对象。重试只能重试可重试动作；决定、外发、发布、实际承诺执行不能因网络重试而重复发生。

## 22. 旧模型迁移与兼容

### 22.1 映射裁决

| 旧对象/字段 | 目标处理 |
|---|---|
| MarketSpace | 保留 Discovery 场景，V3 完整；不再是所有项目必经入口 |
| Definition | 迁到 ProductDefinition 与 Specification 的版本化内容，保留稳定条目标识 |
| RequirementPackage | 转 RequirementChangeSet/DraftProposal + Confirmation，不再只允许定义来源 |
| Requirement.approved/converted | 保留历史事件；新生命周期与投入决定解耦 |
| DevelopmentCase | 保留历史记录与决策材料引用；不再作为 Project 存在前提 |
| InitialPlanCandidate | 计划草案/快照；人工批准并入一个可见决定 |
| 责任确认/执行授权/应用 | 有效政策显式迁移后合并，不能仅把旧按钮藏起来 |
| project_id + product_id 双归属 | 逐条确定 owner，其他关系改绑定；有歧义进入人工队列 |
| Baseline(project_id) | 分类迁入 ProjectBaseline；产品发布证据足够时另建 ProductBaseline |
| wait_days | 转有来源的估计/等待约束，避免与外部承诺双计 |
| AI 直接验证写入 | 分离原始观测、确认、计算、适用性与处置 |

### 22.2 迁移顺序

1. 读取真实 schema/API/政策清单，列出设计与实现差异；本次文档没有完成此检查。
2. 新增不可变来源与映射层，原记录只读保留。
3. 对一个试点项目影子解析工作集、配置和准备度，比较前后结果。
4. 已批准记录保持原证据；来源缺失明确 unknown。
5. 经授权开启新项目政策；旧项目选择继续旧政策或按迁移计划转轨。
6. 核对关联完整性、权限、重复与审计后再逐步替换旧 UI；暂不删除旧表。

回滚应回到旧读路径或冻结新写路径，而不是删除真实执行、签核或外发事实。

## 23. 数据模型完成标准

可以无歧义回答以下问题，才算领域模型覆盖首版：

- 这条需求属于谁，引用到哪些产品/项目，当前和历史修订各是什么？
- 该项目改规格是否会影响父产品；发布目标到底是父产品还是新型号？
- 这份证据是导入现状、AI 候选、确认观测还是正式发布？
- 这台样机在装配、测试和寄给客户时分别是什么配置？
- 哪个交期是真承诺、哪个只是估计、哪个已经实际完成？
- 为什么下一轮受阻，使用哪个政策与哪份证据计算？
- 客户究竟承认了哪个样机/版本的哪些方面？
- 这项变更哪些范围已实施、已验证、已发布或在 ERP 生效？
- 一次更正或并发发布是否会改变旧基线、旧签名和旧测试？答案必须是否定的。

这些问题的可执行验收见 04；AI 处理权威数据的限制见 03。
